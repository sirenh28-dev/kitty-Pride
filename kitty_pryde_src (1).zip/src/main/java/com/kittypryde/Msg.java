package com.kittypryde;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.server.level.ServerPlayer;

/** Mensajes sobre la barra de objetos (action bar). */
public final class Msg {
    private Msg() {}

    public static void overlay(ServerPlayer player, String text) {
        player.connection.send(new ClientboundSetActionBarTextPacket(Component.literal(text)));
    }
}
