package com.kittypryde;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public final class PhaseManager {
    public static final int PHASE_DURATION_TICKS = 15 * 20;
    public static final int DASH_MAX_BLOCKS = 8;

    private static final class State {
        final GameType previous;
        int remaining = PHASE_DURATION_TICKS;
        State(GameType previous) { this.previous = previous; }
    }

    private static final Map<UUID, State> ACTIVE = new HashMap<>();

    private PhaseManager() {}

    public static boolean isPhased(ServerPlayer player) {
        return ACTIVE.containsKey(player.getUUID());
    }

    /** Intangibilidad: usa el modo espectador y recuerda el modo anterior. */
    public static void start(ServerPlayer player) {
        if (isPhased(player) || player.isSpectator()) return;
        ACTIVE.put(player.getUUID(), new State(player.gameMode.getGameModeForPlayer()));
        player.setGameMode(GameType.SPECTATOR);
        effects(player, 1.6f);
        Msg.overlay(player, "Intangible (15 s). Usa /fase para volver antes.");
    }

    public static void end(ServerPlayer player) {
        State state = ACTIVE.remove(player.getUUID());
        if (state == null) return;
        // Si terminas dentro de un bloque solido, el juego te hara daño por asfixia: es el riesgo del poder.
        player.setGameMode(state.previous);
        effects(player, 1.2f);
        Msg.overlay(player, "Sólida de nuevo");
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, State>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, State> entry = it.next();
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) { it.remove(); continue; }
            if (--entry.getValue().remaining <= 0) {
                it.remove();
                player.setGameMode(entry.getValue().previous);
                effects(player, 1.2f);
                Msg.overlay(player, "Sólida de nuevo");
            }
        }
    }

    /** Atraviesa una pared en horizontal, en la direccion en que mira el jugador. */
    public static boolean dash(ServerPlayer player) {
        if (player.isSpectator()) return false;
        Level level = player.level();
        Vec3 look = player.getLookAngle();
        Vec3 dir = new Vec3(look.x, 0, look.z);
        if (dir.lengthSqr() < 1.0E-4) return false;
        dir = dir.normalize();

        boolean crossedSolid = false;
        for (int i = 1; i <= DASH_MAX_BLOCKS; i++) {
            BlockPos feet = BlockPos.containing(player.getX() + dir.x * i, player.getY(), player.getZ() + dir.z * i);
            BlockPos head = feet.above();
            boolean free = isFree(level, feet) && isFree(level, head);
            if (!free) {
                crossedSolid = true;
            } else if (crossedSolid) {
                effects(player, 1.8f);
                player.teleportTo(feet.getX() + 0.5, player.getY(), feet.getZ() + 0.5);
                effects(player, 1.8f);
                return true;
            }
        }
        Msg.overlay(player, "No hay hueco al otro lado (max 8 bloques)");
        return false;
    }

    private static boolean isFree(Level level, BlockPos pos) {
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
                && level.getFluidState(pos).isEmpty();
    }

    private static void effects(ServerPlayer player, float pitch) {
        ServerLevel level = (ServerLevel) player.level();
        level.sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 40, 0.3, 0.5, 0.3, 0.2);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.6f, pitch);
    }
}
