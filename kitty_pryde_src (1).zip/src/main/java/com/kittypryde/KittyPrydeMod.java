package com.kittypryde;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.commands.Commands;

/**
 * Kitty Pryde: intangibilidad temporal + atravesar paredes.
 *  - Cristal fásico (click derecho): intangibilidad 15 s.
 *  - Cristal fásico (agachado + click derecho): atraviesa una pared (max 8 bloques).
 *  - Traje de Shadowcat: 4 piezas (pieza de cuero + tinte azul + tinte amarillo, sin forma).
 *  - /fase : termina la intangibilidad antes de tiempo (en espectador no se pueden usar objetos).
 */
public class KittyPrydeMod implements ModInitializer {
    public static final String MOD_ID = "kittypryde";

    public static Item CRISTAL_FASICO;

    @Override
    public void onInitialize() {
        Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, "cristal_fasico");
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        CRISTAL_FASICO = Registry.register(
                BuiltInRegistries.ITEM, id,
                new PhaseCrystalItem(new Item.Properties().setId(key).stacksTo(1)));

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(output -> output.accept(CRISTAL_FASICO));

        // Traje de Shadowcat (cinta, chaqueta, pantalones y botas)
        ModArmor.register();
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(output -> {
            output.accept(ModArmor.CINTA);
            output.accept(ModArmor.CHAQUETA);
            output.accept(ModArmor.PANTALONES);
            output.accept(ModArmor.BOTAS);
        });

        // Cuenta atras de la intangibilidad
        ServerTickEvents.END_SERVER_TICK.register(PhaseManager::tick);

        // Si el jugador se desconecta intangible, se le devuelve su modo de juego
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> PhaseManager.end(handler.getPlayer()));

        // /fase para salir de la intangibilidad
        CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) ->
                dispatcher.register(Commands.literal("fase").executes(ctx -> {
                    var player = ctx.getSource().getPlayerOrException();
                    if (PhaseManager.isPhased(player)) {
                        PhaseManager.end(player);
                    } else {
                        ctx.getSource().sendFailure(Component.literal("No eres intangible ahora mismo."));
                    }
                    return Command.SINGLE_SUCCESS;
                })));
    }
}
