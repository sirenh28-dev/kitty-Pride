package com.kittypryde;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class PhaseCrystalItem extends Item {
    private static final int DASH_COOLDOWN_TICKS = 40;

    public PhaseCrystalItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide() || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.SUCCESS;
        }
        if (sp.isShiftKeyDown()) {
            if (PhaseManager.dash(sp)) {
                sp.getCooldowns().addCooldown(sp.getItemInHand(hand), DASH_COOLDOWN_TICKS);
            }
        } else {
            PhaseManager.start(sp);
        }
        return InteractionResult.SUCCESS;
    }
}
