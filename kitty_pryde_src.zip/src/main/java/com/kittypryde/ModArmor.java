package com.kittypryde;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

import java.util.EnumMap;
import java.util.Map;

/** Traje de Shadowcat: 4 piezas con proteccion similar al cuero. */
public final class ModArmor {
    /** Apunta a assets/kittypryde/equipment/shadowcat.json */
    public static final ResourceKey<EquipmentAsset> SHADOWCAT_ASSET = ResourceKey.create(
            EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(KittyPrydeMod.MOD_ID, "shadowcat"));

    public static final ArmorMaterial SHADOWCAT = new ArmorMaterial(
            10,                                   // durabilidad base
            defense(),
            15,                                   // encantabilidad
            SoundEvents.ARMOR_EQUIP_LEATHER,
            0.0F,                                 // dureza
            0.0F,                                 // resistencia al empuje
            ItemTags.REPAIRS_LEATHER_ARMOR,
            SHADOWCAT_ASSET);

    public static Item CINTA;
    public static Item CHAQUETA;
    public static Item PANTALONES;
    public static Item BOTAS;

    private ModArmor() {}

    private static Map<ArmorType, Integer> defense() {
        Map<ArmorType, Integer> map = new EnumMap<>(ArmorType.class);
        map.put(ArmorType.HELMET, 1);
        map.put(ArmorType.CHESTPLATE, 3);
        map.put(ArmorType.LEGGINGS, 2);
        map.put(ArmorType.BOOTS, 1);
        map.put(ArmorType.BODY, 3);
        return map;
    }

    private static Item register(String name, ArmorType type) {
        Identifier id = Identifier.fromNamespaceAndPath(KittyPrydeMod.MOD_ID, name);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        return Registry.register(BuiltInRegistries.ITEM, id,
                new Item(new Item.Properties().setId(key).humanoidArmor(SHADOWCAT, type)));
    }

    public static void register() {
        CINTA = register("traje_cinta", ArmorType.HELMET);
        CHAQUETA = register("traje_chaqueta", ArmorType.CHESTPLATE);
        PANTALONES = register("traje_pantalones", ArmorType.LEGGINGS);
        BOTAS = register("traje_botas", ArmorType.BOOTS);
    }
}
